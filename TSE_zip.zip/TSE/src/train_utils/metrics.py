#!/usr/bin/env python
# coding: utf-8

# In[1]:


import torch
import torch.nn.functional as F
import numpy as np
from sklearn.metrics import precision_recall_fscore_support


# In[2]:


# Evaluation metrics
def train_compute_f1(preds, y, aux_eval=False):
    
    rounded_preds = F.softmax(preds, dim=1)
    _, indices = torch.max(rounded_preds, dim=1)
    
    y_pred = np.array(indices.cpu().numpy())
    y_true = np.array(y.cpu().numpy())
    
    if not aux_eval:
        result = precision_recall_fscore_support(y_true, y_pred, average=None, labels=[0, 1, 2])
        f1_average = (result[2][0] + result[2][2]) / 2 # average F1 of FAVOR and AGAINST labels
    else:
        result = precision_recall_fscore_support(y_true, y_pred, average='micro')
        f1_average = result[2]
        
    return f1_average


# In[3]:


from nbconvert import PythonExporter

# Create an instance of the PythonExporter
exporter = PythonExporter()

# Retrieve the notebook contents as Python code
notebook_code, _ = exporter.from_filename('metrics.ipynb')

# Write the Python code to a Python script file
with open('metrics.py', 'w') as f:
    f.write(notebook_code)


# In[ ]:




